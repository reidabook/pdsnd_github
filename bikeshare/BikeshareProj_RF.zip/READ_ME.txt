**READ ME**

References (Other than Udacity):
Pandas Docs
https://pandas.pydata.org/pandas-docs/version/0.23.4/generated/pandas.DataFrame.html

Python docs
https://docs.python.org/3/

Stack Overflow (via google search)
primarily for clarifying questions on working with DataFrames

w3schools
For further detail on python functions
https://www.w3schools.com/python/
